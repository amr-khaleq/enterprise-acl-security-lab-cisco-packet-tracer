# GitHub Upload Guide

## Recommended repository name

`enterprise-acl-security-lab-cisco-packet-tracer`

## Method A — GitHub website

1. Sign in to GitHub.
2. Click **New repository**.
3. Name it `enterprise-acl-security-lab-cisco-packet-tracer`.
4. Set it to **Public** for a portfolio repository.
5. Create the repository.
6. Upload all files and folders from this project package.
7. Before uploading, place your actual Packet Tracer file at:
   `packet-tracer/Enterprise-ACL-Security-Lab.pkt`
8. Commit with a message such as:
   `Add enterprise ACL security lab`

## Method B — Git CLI

From the project folder:

```bash
git init
git branch -M main
git add .
git commit -m "Add enterprise ACL security lab"
git remote add origin https://github.com/YOUR-USERNAME/enterprise-acl-security-lab-cisco-packet-tracer.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your actual GitHub username.

## Screenshots to add

Recommended names:

```text
docs/topology.png
docs/show-access-lists.png
docs/vlan-trunk.png
docs/nat-translations.png
docs/acl-testing.png
```

Do not include real passwords or private credentials in screenshots.

## LinkedIn

1. Copy the content from `LinkedIn_Post.md`.
2. Replace the GitHub placeholder with your repository URL.
3. Attach the topology screenshot plus one ACL verification screenshot.
4. Publish the post.
