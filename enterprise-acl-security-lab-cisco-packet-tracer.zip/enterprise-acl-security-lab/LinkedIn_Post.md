# LinkedIn Project Post

🚀 **Completed a Cisco Packet Tracer ACL Security Lab**

I recently built a practical **Enterprise ACL Security Lab** in Cisco Packet Tracer to strengthen my hands-on networking and security skills.

### 🔐 What I implemented

• VLAN segmentation for SALES, HR, IT, and SERVERS  
• Router-on-a-Stick for inter-VLAN routing  
• Named Extended ACLs for traffic filtering  
• Standard ACL for management access control  
• Wildcard masks, `permit`, `deny`, `host`, and `any`  
• DHCP configuration  
• NAT/PAT for Internet access  
• SSH management  
• ACL verification using `show access-lists` and interface commands  
• Connectivity testing and ACL troubleshooting

### 🧪 Security Policy

• SALES → HR: Denied  
• SALES → IT: Denied  
• SALES → SERVERS: Allowed  
• HR → SALES: Denied  
• HR → IT: Denied  
• HR → SERVERS: Allowed  
• IT → All Networks: Allowed

A key part of the lab was validating the policy with real traffic and reading ACL **match counters** to understand which rule handled each packet.

📌 **Tools:** Cisco Packet Tracer, Cisco IOS  
📌 **Focus:** ACL, VLAN, Inter-VLAN Routing, DHCP, NAT/PAT, SSH, Troubleshooting

🔗 **GitHub:** [PASTE YOUR REPOSITORY LINK HERE]

#Cisco #CCNA #Networking #NetworkSecurity #ACL #CiscoPacketTracer #NetworkEngineer #ITInfrastructure
