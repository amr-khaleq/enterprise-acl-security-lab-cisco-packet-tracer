# 🔐 Enterprise ACL Security Lab — Cisco Packet Tracer

A practical Cisco Packet Tracer portfolio lab focused on Access Control Lists (ACLs), inter-VLAN security, DHCP, NAT/PAT, SSH management, verification, and troubleshooting.

## 🎯 Objective

Build a small enterprise network where traffic is controlled between departments using Standard ACLs and Named Extended ACLs.

## 🧩 Technologies

- VLAN 10 — SALES
- VLAN 20 — HR
- VLAN 30 — IT
- VLAN 40 — SERVERS
- Router-on-a-Stick / 802.1Q
- Standard ACL
- Named Extended ACL
- Wildcard masks
- `permit`, `deny`, `host`, `any`
- ACL direction: `in` / `out`
- DHCP
- NAT/PAT
- SSH
- Verification and troubleshooting

## 🗺️ Addressing Plan

| Device | IP | VLAN | Gateway |
|---|---|---:|---|
| SALES-PC | 192.168.10.10 | 10 | 192.168.10.1 |
| HR-PC | 192.168.20.10 | 20 | 192.168.20.1 |
| IT-PC | 192.168.30.10 | 30 | 192.168.30.1 |
| WEB-SERVER | 192.168.40.10 | 40 | 192.168.40.1 |
| DNS-SERVER | 192.168.40.20 | 40 | 192.168.40.1 |
| R1-EDGE G0/1 | 203.0.113.2/30 | WAN | 203.0.113.1 |
| ISP-R1 G0/0 | 203.0.113.1/30 | WAN | — |
| ISP-R1 G0/1 | 8.8.8.1/24 | Internet simulation | — |

## 🔌 Port Map

| Connection | Port |
|---|---|
| SALES-PC → SW1 | Fa0/1 |
| HR-PC → SW1 | Fa0/2 |
| IT-PC → SW1 | Fa0/3 |
| WEB-SERVER → SW1 | Fa0/4 |
| DNS-SERVER → SW1 | Fa0/5 |
| SW1 → R1-EDGE | Fa0/24 ↔ G0/0 |
| R1-EDGE → ISP-R1 | G0/1 ↔ G0/0 |

## 🔐 Security Policy

| Source | Destination | Expected |
|---|---|---|
| SALES | HR | ❌ Deny |
| SALES | IT | ❌ Deny |
| SALES | SERVERS | ✅ Permit |
| SALES | Internet | ✅ Permit |
| HR | SALES | ❌ Deny |
| HR | IT | ❌ Deny |
| HR | SERVERS | ✅ Permit |
| HR | Internet | ✅ Permit |
| IT | Any network | ✅ Permit |

### Standard ACL management example

A Standard ACL is used as a source-based restriction for VTY/SSH management access.

> The original scenario mentions Guest. This repository documents Guest as a future extension unless VLAN 50 is actually added to the Packet Tracer file.

## 🖼️ Topology

```text
                         +----------------+
                         |    ISP-R1      |
                         |  203.0.113.1   |
                         +--------+-------+
                                  |
                         203.0.113.0/30
                                  |
                         +--------+-------+
                         |    R1-EDGE     |
                         | Router-on-a-   |
                         |     Stick      |
                         +--------+-------+
                                  |
                              802.1Q Trunk
                                  |
                         +--------+-------+
                         |      SW1       |
                         +--+----+----+--+
                            |    |    |
                           V10  V20  V30
                         SALES  HR   IT
                            |
                           V40
                         SERVERS
                         /      \
                  WEB-SERVER   DNS-SERVER
```

## ⚙️ Key ACL Configuration

### SALES

```cisco
ip access-list extended SALES-ACL
deny ip 192.168.10.0 0.0.0.255 192.168.20.0 0.0.0.255
deny ip 192.168.10.0 0.0.0.255 192.168.30.0 0.0.0.255
permit ip 192.168.10.0 0.0.0.255 192.168.40.0 0.0.0.255
permit ip 192.168.10.0 0.0.0.255 any
!
interface g0/0.10
 ip access-group SALES-ACL in
```

### HR

```cisco
ip access-list extended HR-ACL
deny ip 192.168.20.0 0.0.0.255 192.168.10.0 0.0.0.255
deny ip 192.168.20.0 0.0.0.255 192.168.30.0 0.0.0.255
permit ip 192.168.20.0 0.0.0.255 192.168.40.0 0.0.0.255
permit ip 192.168.20.0 0.0.0.255 any
!
interface g0/0.20
 ip access-group HR-ACL in
```

### IT

```cisco
ip access-list extended IT-ACL
permit ip 192.168.30.0 0.0.0.255 any
!
interface g0/0.30
 ip access-group IT-ACL in
```

### Standard ACL / SSH example

```cisco
ip access-list standard BLOCK-SALES-PC
deny host 192.168.10.10
permit any
!
line vty 0 4
 login local
 transport input ssh
 access-class BLOCK-SALES-PC in
```

## 🔄 NAT/PAT

```cisco
access-list 1 permit 192.168.10.0 0.0.0.255
access-list 1 permit 192.168.20.0 0.0.0.255
access-list 1 permit 192.168.30.0 0.0.0.255
access-list 1 permit 192.168.40.0 0.0.0.255
ip nat inside source list 1 interface g0/1 overload
```

## 🧪 Verification

```cisco
show vlan brief
show interfaces trunk
show ip interface brief
show ip route
show access-lists
show ip access-lists
show ip interface g0/0.10
show ip interface g0/0.20
show ip interface g0/0.30
show ip dhcp binding
show ip nat translations
show ip nat statistics
```

### Expected tests

| Test | Result |
|---|---|
| SALES → HR ping | ❌ |
| SALES → IT ping | ❌ |
| SALES → WEB | ✅ |
| HR → SALES ping | ❌ |
| HR → IT ping | ❌ |
| HR → WEB | ✅ |
| IT → SALES ping | ✅ |
| IT → HR ping | ✅ |
| IT → WEB ping | ✅ |
| Internal → 8.8.8.1 | ✅ |

## 🔎 ACL Match Counters

Run:

```cisco
show access-lists
```

Example:

```text
deny ip 192.168.10.0 0.0.0.255 192.168.20.0 0.0.0.255 (5 matches)
```

`5 matches` means five packets matched that specific ACL entry.

## 🛠️ Troubleshooting Flow

1. PC IP
2. Default gateway
3. VLAN assignment
4. Trunk
5. Router subinterface state
6. Routing table
7. ACL exists
8. ACL applied
9. Correct direction (`in` / `out`)
10. Rule order
11. Implicit deny

## 📁 Repository Structure

```text
enterprise-acl-security-lab-cisco-packet-tracer/
├── README.md
├── LinkedIn_Post.md
├── GitHub_Upload_Guide.md
├── LICENSE
├── .gitignore
├── configs/
│   ├── R1-EDGE.txt
│   ├── SW1.txt
│   └── ISP-R1.txt
├── docs/
│   ├── addressing-plan.md
│   └── topology.md
├── tests/
│   └── ACL-Test-Plan.md
└── packet-tracer/
    └── Enterprise-ACL-Security-Lab.pkt
```

## 👨‍💻 Portfolio Focus

This project demonstrates hands-on practice with Cisco IOS, VLAN segmentation, inter-VLAN routing, ACL policy implementation, DHCP, NAT/PAT, SSH, verification, and troubleshooting.
