# Topology

```text
SALES-PC ---- Fa0/1      Fa0/24
HR-PC ------- Fa0/2   SW1 ===== R1-EDGE ===== ISP-R1
IT-PC ------- Fa0/3      trunk      G0/0       G0/1
WEB-SERVER -- Fa0/4
DNS-SERVER -- Fa0/5
```

R1-EDGE G0/0 is configured for 802.1Q trunking with Router-on-a-Stick.
