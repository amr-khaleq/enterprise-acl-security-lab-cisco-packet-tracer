Place your finished Packet Tracer file here with this exact filename:

Enterprise-ACL-Security-Lab.pkt

Note: the assistant cannot generate the Cisco Packet Tracer binary .pkt file itself. Build/save the lab in Packet Tracer, then copy it here before uploading to GitHub.
