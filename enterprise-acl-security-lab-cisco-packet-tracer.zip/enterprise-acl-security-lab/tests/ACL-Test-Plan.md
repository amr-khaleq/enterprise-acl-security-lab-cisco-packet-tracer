# ACL Test Plan

## Baseline

Before enabling ACLs, confirm basic routing between VLANs.

## Security Tests

```text
SALES -> 192.168.20.10  Expected: FAIL
SALES -> 192.168.30.10  Expected: FAIL
SALES -> 192.168.40.10  Expected: SUCCESS
SALES -> 8.8.8.1        Expected: SUCCESS

HR -> 192.168.10.10     Expected: FAIL
HR -> 192.168.30.10     Expected: FAIL
HR -> 192.168.40.10     Expected: SUCCESS
HR -> 8.8.8.1           Expected: SUCCESS

IT -> 192.168.10.10     Expected: SUCCESS
IT -> 192.168.20.10     Expected: SUCCESS
IT -> 192.168.40.10     Expected: SUCCESS
```

## Verification commands

```cisco
show access-lists
show ip access-lists
show ip interface g0/0.10
show ip interface g0/0.20
show ip interface g0/0.30
show ip route
show ip nat translations
show ip nat statistics
show ip dhcp binding
```
